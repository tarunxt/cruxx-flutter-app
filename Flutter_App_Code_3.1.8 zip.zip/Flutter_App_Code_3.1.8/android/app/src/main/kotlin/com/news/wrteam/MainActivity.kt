package YOUR_PACKAGE_NAME_HERE

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity() {}
